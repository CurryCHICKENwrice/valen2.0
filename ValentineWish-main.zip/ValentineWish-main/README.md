<h1 align="center">
    Valentine's Wish
</h1>

[![Author](https://img.shields.io/badge/author-GovindCodes-green)](https://github.com/GovindCodes)


#### [See it Live](https://govindcodes.github.io/ValentineWish/)

## Make your own version :computer:

:camera::camera::camera::camera::camera::camera::camera:
*Start with Smile*:smile::smile:

* Fork the repository
* Open `customize.json` and replace name/wish-message/image with your own
* Turn on GitHub pages for the repository (Settings > GitHub Pages)
* Send the URL that you get at the above step to your friend


## Contributing

If you have any idea to make it more interesting, feel free to send a PR, or create an issue for a feature request.

Stay happy and keep the people you care about happy. :)

#### OwnerShip
 The animations used in the Repository is created by Afiur Rahman Fahim(faahim).:smile:
